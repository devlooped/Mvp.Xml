//  *********************************************************************************
//  File:	sseAtomMerge.js
//  Notes:	You must run this file with cscript.exe (i.e. not wscript.exe)
//
//  Copyright (c) 2006 Microsoft Corporation.  All Rights Reserved.
//  *********************************************************************************


//  -------------------------- MAIN (BEGIN) --------------------------

//  Validate arguments
var g_Arguments = WScript.Arguments;
if (g_Arguments.length < 2)
	{
	DisplayUsage();
	WScript.Quit();
	}

//  Get required parameters
var g_LocalPath = g_Arguments(0);
var g_IncomingPath = g_Arguments(1);

var g_pILocalAtomXmlDOMDocument = null;

try
	{
	//  Create instance of XML DOM
	g_pILocalAtomXmlDOMDocument = new ActiveXObject("Microsoft.XMLDOM");
	g_pILocalAtomXmlDOMDocument.async = false;

	//  Load local document	
	var Success = g_pILocalAtomXmlDOMDocument.load(g_LocalPath);
	if (!Success)
		throw new Error(0, "IXmlDocument::load failed");
	}
catch (e)
	{
	WScript.Echo("Exception while loading '" + g_LocalPath +"': " + e.message);
	WScript.Quit();
	}

//  Get local "feed" element
var g_pILocalFeedXmlDOMElement = g_pILocalAtomXmlDOMDocument.documentElement;

//  Check if sse namespace exists, if not then display error
if (g_pILocalFeedXmlDOMElement.getAttribute("xmlns:sx") == null)
	{
	WScript.Echo("Can't process local Atom file - it does not contain a 'sx' namespace!");
	WScript.Quit();
	}

var g_pIIncomingAtomXmlDOMDocument = null;

try
	{
	//  Create instance of XML DOM
	g_pIIncomingAtomXmlDOMDocument = new ActiveXObject("Microsoft.XMLDOM");
	g_pIIncomingAtomXmlDOMDocument.async = false;

	//  Load incoming document	
	var Success = g_pIIncomingAtomXmlDOMDocument.load(g_IncomingPath);
	if (!Success)
		throw new Error(0, "IXmlDocument::load failed");
	}
catch (e)
	{
	WScript.Echo("Exception while loading '" + g_IncomingPath +"': " + e.message);
	WScript.Quit();
	}

//  Get incoming "feed" element
var g_pIIncomingFeedXmlDOMElement = g_pIIncomingAtomXmlDOMDocument.documentElement;

//  Check if sse namespace exists, if not then display error
if (g_pIIncomingFeedXmlDOMElement.getAttribute("xmlns:sx") == null)
	{
	WScript.Echo("Can't process incoming Atom file - it does not contain a 'sx' namespace!");
	WScript.Quit();
	}

//  *********************************************************************************
//  BIG HONKING NOTE:  We only deal with "entry" elements when merging, so any other
//                     changes made in the incoming document are ignored.  Remember that
//                     the goal of SSE isn't to replicate Atom files, it is to 
//                     replicate items via Atom.
//  *********************************************************************************

//  Create hashtable for local SSENodes
var g_LocalSSENodeHashtable = new Object();

//  Populate local SSENode hashtable
PopulateSSENodesFromXmlDOMElement(g_LocalSSENodeHashtable, g_pILocalFeedXmlDOMElement);

//  Create hashtable for incoming SSENodes
var g_IncomingSSENodeHashtable = new Object();

//  Populate incoming SSENode hashtable
PopulateSSENodesFromXmlDOMElement(g_IncomingSSENodeHashtable, g_pIIncomingFeedXmlDOMElement);

var g_pIOutputAtomXmlDOMDocument = 	null;

try
	{
	//  Create instance of XML DOM
	g_pIOutputAtomXmlDOMDocument = new ActiveXObject("Microsoft.XMLDOM");
	g_pIOutputAtomXmlDOMDocument.async = false;

	//  Create output feed document based on local feed document
	g_pILocalAtomXmlDOMDocument.save(g_pIOutputAtomXmlDOMDocument);
	if (!Success)
		throw new Error(0, "IXmlDocument::load failed");
	}
catch (e)
	{
	WScript.Echo("Exception while saving local document: " + e.message);
	WScript.Quit();
	}

//  Create output array
var g_OutputSSENodeArray = new Array();

//  Get output "feed" element
var g_pIOutputFeedXmlDOMElement = g_pIOutputAtomXmlDOMDocument.documentElement;

//  Get "entry" elements of "feed" element
var g_pIEntryXmlDOMElements = g_pIOutputFeedXmlDOMElement.selectNodes("entry");

//  *********************************************************************************
//  BIG HONKING NOTE:  Iterate all "entry" elements of the "feed" element (start
//                     with last and progress to first) in order to remove them.  We 
//                     remove them because there is further processing below that 
//                     will take the appropriate "entry" elements from the local and 
//                     incoming documents and add them.  Note that we don't just remove 
//                     the "feed" element and add a new one in it's place because 
//                     a) there could be attributes on the "feed" element and b)
//                     there could be non-"entry" elements of the "feed" element.

	for (var Index = g_pIEntryXmlDOMElements.length - 1; Index >= 0; --Index)
		{
		//  Get next "entry" element
		var pIEntryXmlDOMElement = g_pIEntryXmlDOMElements(Index);
	
		//  Remove "entry" element from output "feed" element
		g_pIOutputFeedXmlDOMElement.removeChild(pIEntryXmlDOMElement);
		}
		
//  *********************************************************************************

var g_HashtableKey = null;

//  Iterate items in local SSENode hashtable
for (g_HashtableKey in g_LocalSSENodeHashtable)
	{
	//  Get SSENode from local hashtable
	var LocalSSENode = g_LocalSSENodeHashtable[g_HashtableKey];

	//  Get reference to local SSESyncNode
	var LocalSSESyncNode = LocalSSENode.m_SSESyncNode;

	//  Get SSENode from incoming hashtable
	var IncomingSSENode = g_IncomingSSENodeHashtable[g_HashtableKey];
	
	//  Validate incoming SSENode exists, if not then node was added to local
	//  document
	if (IncomingSSENode == null)
		{
		//  Create clone of LocalSSENode
		var ClonedSSENode = CloneSSENode(LocalSSENode);

		//  Add cloned SSENode to output array
		g_OutputSSENodeArray[g_OutputSSENodeArray.length] = ClonedSSENode;
		
		//  Continue loop
		continue;
		}

    //  Get merged SSENode
    var MergedSSENode = MergeSSENodes(LocalSSENode, IncomingSSENode);

	//  Add merged SSENode to output array
	g_OutputSSENodeArray[g_OutputSSENodeArray.length] = MergedSSENode;
	
	//  Set incoming hashtable entry to null so we don't process it during
	//  second pass below
	g_IncomingSSENodeHashtable[g_HashtableKey] = null;
	}

//  Iterate items in incoming SSENode hashtable - all remaining items are
//  guaranteed to be additions to incoming document
for (g_HashtableKey in g_IncomingSSENodeHashtable)
	{
	//  Get SSENode from incoming hashtable
	var IncomingSSENode = g_IncomingSSENodeHashtable[g_HashtableKey];

	//  Validate SSENode exists, if not then just continue loop because
	//  entry was set to null when processing local hashtable
	if (IncomingSSENode == null)
		continue;

	//  Create clone of IncomingSSENode
	var ClonedSSENode = CloneSSENode(IncomingSSENode);
	
	//  Add cloned SSENode to output array
	g_OutputSSENodeArray[g_OutputSSENodeArray.length] = ClonedSSENode;
	}
	
//  Iterate output SSENodes
for (var Index = 0; Index < g_OutputSSENodeArray.length; ++Index)
	{
	//  Get next output SSENode
	var OutputSSENode = g_OutputSSENodeArray[Index];
	
	//  Append output SSENode's element to "feed" element
	g_pIOutputFeedXmlDOMElement.appendChild(OutputSSENode.m_pIXmlDOMElement);
	}

//  Save modified contents to standand output stream
WScript.StdOut.Write(g_pIOutputAtomXmlDOMDocument.xml);

//  -------------------------- MAIN (END) --------------------------


//  -------------------------- SSENodeClass (BEGIN) --------------------------

function SSENodeClass(i_pIXmlDOMElement)
	{
	//  Assign m_pIOXmlDOMElement member variable
	this.m_pIXmlDOMElement = i_pIXmlDOMElement;

	//  Assign m_SSESyncNode member variable by creating a new instance of 
	//  SSESyncNode and passing a reference to the current SSENode
	this.m_SSESyncNode = new SSESyncNodeClass(this);
	}

//  -------------------------- SSENodeClass (END) --------------------------



//  -------------------------- SSESyncNodeClass (BEGIN) --------------------------
	
function SSESyncNodeClass(i_SSENode)
	{
	//  Assign m_SSENode member variable
	this.m_SSENode = i_SSENode;
	
	//  Get reference to SSENode's XmlDOMElement
	var pIXmlDOMElement = this.m_SSENode.m_pIXmlDOMElement;
	
	//  Assign m_pIXmlDOMElement member variable
	this.m_pIXmlDOMElement = pIXmlDOMElement.selectSingleNode("sx:sync");
	
	//  Validate m_pISyncXmlDOMElement member variable
	if (this.m_pIXmlDOMElement == null)
		{
		WScript.Echo("Unable to find 'sx:sync' element where parent id='" + this.m_SSENode.m_ParentID + "'");
		WScript.Quit(0);
		}

	//  Assign m_ID member variable
	this.m_ID = this.m_pIXmlDOMElement.getAttribute("id");

	//  Validate m_ID member variable
	if (this.m_ID == null)
		{
		WScript.Echo("Unable to find 'id' attribute for 'sx:sync' element where parent id='" + this.m_SSENode.m_ParentID + "'");
		WScript.Quit(0);
		}

	//  Assign m_Updates member variable
	this.m_Updates = this.m_pIXmlDOMElement.getAttribute("updates");

	//  Validate m_Updates member variable
	if (this.m_Updates == null)
		{
		WScript.Echo("Unable to find 'updates' attribute for 'sx:sync' element where id='" + this.m_ID + "'");
		WScript.Quit(0);
		}

	//  Assign m_NoConflicts member variable
	var NoConflicts = this.m_pIXmlDOMElement.getAttribute("noconflicts");
	
	//  Validate m_Conflict member variable
	if (NoConflicts == "true")
		this.m_NoConflicts = true;
	else
		this.m_NoConflicts = false;

    //  Assign m_SSEConflictNodes member variable by creating a new array
    this.m_SSEConflictNodes = new Array();

    if (!this.m_NoConflicts)
		{
		//  Get reference to "sx:conflicts" element
		this.m_pIConflictsXmlDOMElement = this.m_pIXmlDOMElement.selectSingleNode("sx:conflicts");
    	
		//  Validate that "sx:conflicts" element exists
		if (this.m_pIConflictsXmlDOMElement != null)
		    {
		    //  Get conflict "entry" elements
		    var pIConflictItemXmlDOMElements = this.m_pIConflictsXmlDOMElement.selectNodes("entry");
    		
		    //  Iterate conflict "entry" elements
		    for (var Index = 0; Index < pIConflictItemXmlDOMElements.length; ++Index)
			    {
			    //  Get reference to next conflict "entry" element
			    var pIConflictItemXmlDOMElement = pIConflictItemXmlDOMElements(Index);
    			
			    //  Assign array entry by creating a new instance of SSENode and passing
			    //  a reference to the current conflict "entry" element
			    this.m_SSEConflictNodes[Index] = new SSENodeClass(pIConflictItemXmlDOMElement);
			    }
		    }
		}

    //  Assign m_SSEHistoryNodes member variable by creating a new array
    this.m_SSEHistoryNodes = new Array();

    //  Get "sx:history" elements
    var pIHistoryXmlDOMElements = this.m_pIXmlDOMElement.selectNodes("sx:history");
		    
    //  Iterate "sx:history" elements
    for (var Index = 0; Index < pIHistoryXmlDOMElements.length; ++Index)
	    {
	    //  Get reference to next "sx:history" element
	    var pIHistoryXmlDOMElement = pIHistoryXmlDOMElements(Index);
		
	    //  Assign array entry by creating a new instance of SSEHistoryNode and passing
	    //  a reference to the current "sx:history" element
	    this.m_SSEHistoryNodes[Index] = new SSEHistoryNodeClass(this, pIHistoryXmlDOMElement);
	    }
	}
	
//  -------------------------- SSESyncNodeClass (END) --------------------------


//  -------------------------- SSEHistoryNodeClass (BEGIN) --------------------------

function SSEHistoryNodeClass(i_SSESyncNode, i_pIHistoryXmlDOMElement)
	{
	//  Assign m_SSESyncNode member variable
	this.m_SSESyncNode = i_SSESyncNode;
	
	//  Assign m_pIXmlDOMElement member variable		
	this.m_pIXmlDOMElement = i_pIHistoryXmlDOMElement;
	
	//  Validate m_pIXmlDOMElement member variable
	if (this.m_pIXmlDOMElement == null)
		{
		WScript.Echo("Unable to find 'sx:history' element for 'sx:sync' element where id='" + this.m_SSESyncNode.m_ID + "'");
		return;
		}

	//  Assign m_Sequence member variable
	this.m_Sequence = this.m_pIXmlDOMElement.getAttribute("sequence");
        
	//  Assign m_When member variable
	this.m_When = this.m_pIXmlDOMElement.getAttribute("when");
	
	//  Assign m_By member variable
	this.m_By = this.m_pIXmlDOMElement.getAttribute("by");
	
	//  Validate that either m_When or m_By member variable have been assigned
	if ((this.m_When == null) && (this.m_By == null))
		{
		WScript.Echo("Unable to find 'when' or 'by' attribute in 'sx:history' element for 'sx:sync' element where id='" + this.m_SSESyncNode.m_ID + "'");
		WScript.Quit(0);
		}
	}

//  -------------------------- SSEHistoryNodeClass (BEGIN) --------------------------


function PopulateSSENodesFromXmlDOMElement(i_Hashtable, i_pIXmlDOMElement)
	{
	//  Get "entry" elements
	var pIItemXmlDOMElements = i_pIXmlDOMElement.selectNodes("entry");

	//  Iterate "entry" elements
	for (var Index = 0; Index < pIItemXmlDOMElements.length; ++Index)
		{
		//  Get reference to next "entry" element
		var pIItemXmlDOMElement = pIItemXmlDOMElements(Index);
		
		//  Create new instance of SSENodeClass
		var SSENode = new SSENodeClass(pIItemXmlDOMElement);
				
		//  Get reference to SSESyncNode
		var SSESyncNode = SSENode.m_SSESyncNode;

		//  Add SSENode to hashtable using SSESyncNode's id as key
		i_Hashtable[SSESyncNode.m_ID] = SSENode;
		}
	}
	
function MergeSSENodes(i_LocalSSENode, i_IncomingSSENode)
	{
	//  Create collection for local item and local item's conflicts
	var LocalItemCollection = new Array();
	
	//  Created clone of local SSENode
	var ClonedLocalSSENode = CloneSSENode(i_LocalSSENode);
	
	//  Get reference to local SSESyncNode
	var ClonedLocalSSESyncNode = ClonedLocalSSENode.m_SSESyncNode;
	
	//  Populate collection with clone of local item's conflicts
	for (var Index = 0; Index < ClonedLocalSSESyncNode.m_SSEConflictNodes.length; ++Index)
	    LocalItemCollection[LocalItemCollection.length] = CloneSSENode(ClonedLocalSSESyncNode.m_SSEConflictNodes[Index]);

	//  See if "sx:conflicts" element exists, if so remove it
	if (ClonedLocalSSESyncNode.m_pIConflictsXmlDOMElement != null)
	    ClonedLocalSSESyncNode.m_pIConflictsXmlDOMElement.parentNode.removeChild(ClonedLocalSSESyncNode.m_pIConflictsXmlDOMElement);
	    
	//  Populate collection with clone of local item
	LocalItemCollection[LocalItemCollection.length] = ClonedLocalSSENode;

	//  Create collection for incoming item and incoming item's conflicts
	var IncomingItemCollection = new Array();
	
	//  Created clone of incoming SSENode
	var ClonedIncomingSSENode = CloneSSENode(i_IncomingSSENode);

	//  Get reference to incoming SSESyncNode
	var ClonedIncomingSSESyncNode = ClonedIncomingSSENode.m_SSESyncNode;
	
	//  Populate collection with clone of incoming item's conflicts
	for (var Index = 0; Index < ClonedIncomingSSESyncNode.m_SSEConflictNodes.length; ++Index)
	    IncomingItemCollection[IncomingItemCollection.length] = CloneSSENode(ClonedIncomingSSESyncNode.m_SSEConflictNodes[Index]);

	//  See if "sx:conflicts" element exists, if so remove it
	if (ClonedIncomingSSESyncNode.m_pIConflictsXmlDOMElement != null)
	    ClonedIncomingSSESyncNode.m_pIConflictsXmlDOMElement.parentNode.removeChild(ClonedIncomingSSESyncNode.m_pIConflictsXmlDOMElement);
	    
	//  Populate collection with clone of incoming item
	IncomingItemCollection[IncomingItemCollection.length] = ClonedIncomingSSENode;

	//  Create collection for merge result 
	var MergeResultItemCollection = new Array();

	var WinnerSSENode = null;

	//  Process collections using local item collection as outer collection
	//  and incoming item collection as inner collection	
	WinnerSSENode = ProcessCollections(LocalItemCollection, IncomingItemCollection, MergeResultItemCollection, WinnerSSENode);
	
	//  Process collections using incoming item collection as outer collection
	//  and local item collection as inner collection	
	WinnerSSENode = ProcessCollections(IncomingItemCollection, LocalItemCollection, MergeResultItemCollection, WinnerSSENode);

	//  Get reference to winner's SSESyncNode
	var WinnerSSESyncNode = WinnerSSENode.m_SSESyncNode;

	//  If the "noconflicts" attribute is true, or if there is only one
	//  item in the merge result collection (i.e. the winner), then we are 
	//  done processing
	if (WinnerSSESyncNode.m_NoConflicts || (MergeResultItemCollection.length == 1))
	    return WinnerSSENode;
    
	//  Create "sx:conflicts" element for winner
	var pIWinnerConflictsXmlDOMElement = g_pIOutputAtomXmlDOMDocument.createElement("sx:conflicts");
    
	//  Append "sx:conflicts" element to winner's "sx:sync" element
	WinnerSSESyncNode.m_pIXmlDOMElement.appendChild(pIWinnerConflictsXmlDOMElement);
    
	//  Get reference to winner's conflict nodes
	var WinnerSSEConflictNodes = WinnerSSESyncNode.m_SSEConflictNodes;
    
	//  Create empty array to hold winner's conflict nodes
	WinnerSSEConflictNodes = new Array();
    
	//  Iterate items in merge result collection    
	for (var Index = 0; Index < MergeResultItemCollection.length; ++Index)
	    {
	    //  Get next item in merge result collection
	    var MergeResultItem = MergeResultItemCollection[Index];
        
	    //  If the merge result item matches the winner item, just
	    //  continue the loop
	    if (0 == CompareSSENodes(WinnerSSENode, MergeResultItem))
	        continue;

	    //  Get reference to merge result item's element
	    var pIMergeResultItemXmlDOMElement = MergeResultItemCollection[Index].m_pIXmlDOMElement;
                    
	    //  Append merge result's element to winner's "sx:conflicts" element
	    pIWinnerConflictsXmlDOMElement.appendChild(pIMergeResultItemXmlDOMElement);
        
	    //  Add new item to winner's conflict nodes
	    WinnerSSEConflictNodes[WinnerSSEConflictNodes.length] = new SSENodeClass(pIMergeResultItemXmlDOMElement);
	    }
        
	return WinnerSSENode;
	}
 
function ProcessCollections(i_OuterSSENodeCollection, i_InnerSSENodeCollection, io_MergeSSENodeCollection, i_WinnerSSENode)
    {
    //  Iterate outer SSENode collection
    for (var OuterSSENodeCollectionIndex = 0; OuterSSENodeCollectionIndex < i_OuterSSENodeCollection.length; ++OuterSSENodeCollectionIndex)
        {
        //  Get next SSENode in outer collection
        var OuterSSENode = i_OuterSSENodeCollection[OuterSSENodeCollectionIndex];
        
        //  Get reference to outer SSESyncNode
        var OuterSSESyncNode = OuterSSENode.m_SSESyncNode;

        var OuterSSENodeSubsumed = false;
        
        //  Iterate inner SSENode collection
        for (var InnerSSENodeCollectionIndex = 0; InnerSSENodeCollectionIndex < i_InnerSSENodeCollection.length; ++InnerSSENodeCollectionIndex)
            {
            //  Get next SSENode in inner collection
            var InnerSSENode = i_InnerSSENodeCollection[InnerSSENodeCollectionIndex];

            //  Check value of inner SSENode exists - if not then
            //  just continue loop
            if (InnerSSENode == null)
                continue;
                            
            //  Get reference to inner SSESyncNode
            var InnerSSESyncNode = InnerSSENode.m_SSESyncNode;

            //  Get the topmost "sx:history" element for the outer SSESyncNode
            var OuterSSEHistoryNode = OuterSSENode.m_SSESyncNode.m_SSEHistoryNodes[0];        
            
            //  Iterate SSEHistoryNodes for inner SSESyncNode
            for (var HistoryIndex = 0; HistoryIndex < InnerSSESyncNode.m_SSEHistoryNodes.length; ++HistoryIndex)
                {
                //  Get next SSEHistoryNode
                var InnerSSEHistoryNode = InnerSSESyncNode.m_SSEHistoryNodes[HistoryIndex];
                
                //  See if "by" attribute exists for outer SSEHistoryNode and if
                //  it does, see if it's value matches "by" attribute value for 
                //  inner SSEHistoryNode
                if ((OuterSSEHistoryNode.m_By != null) && (OuterSSEHistoryNode.m_By == InnerSSEHistoryNode.m_By))
                    {
                    //  See if "sequence" attribute for the inner SSEHistoryNode 
                    //  is greater than or equal to the "sequence" attribute for
                    //  the outer SSEHistoryNode
                    if (InnerSSEHistoryNode.m_Sequence >= OuterSSEHistoryNode.m_Sequence)
                        {
                        //  Indicate subsumption
                        OuterSSENodeSubsumed = true;
                        }

                    //  Stop iterating SSEHistoryNodes
                    break;
                    }
                    
                //  See if "by" attribute does not exist for both outer SSEHistoryNode
                //  and inner SSEHistoryNode
                else if ((OuterSSEHistoryNode.m_By == null) && (InnerSSEHistoryNode.m_By == null))
                    {
                    //  See if "when" attribute exists for both outer SSEHistoryNode
                    //  and inner SSEHistoryNode
                    if ((InnerSSEHistoryNode.m_When != null) && (OuterSSEHistoryNode.m_When != null))
                        {
                        //  See if normalized dates match - if so then the outer SSENode
                        //  is subsumed
                        if (InnerSSEHistoryNode.m_When == OuterSSEHistoryNode.m_When)
                            {
                            //  Indicate subsumption
                            OuterSSENodeSubsumed = true;
        				    
                            //  Stop iterating SSEHistoryNodes
                            break;
                            }
                        }
                    }
                }

            //  Check for subsumption
            if (OuterSSENodeSubsumed)
                {
                //  Stop iterating inner SSENodes        
                break;
                }
            }

        //  Check for subsumption
        if (OuterSSENodeSubsumed)
            {
            //  Remove outer SSENode from outer SSENode collection
            i_OuterSSENodeCollection[OuterSSENodeCollectionIndex] = null;
            
            //  Continue iterating outer SSENodes
            continue;
            }

        //  See if outer SSESyncNode has any SSEConflictNodes
        if (OuterSSESyncNode.m_SSEConflictNodes.length > 0)
            {
            //  Remove the "sx:conflicts" sub-element for outer
            //  SSESyncNode
            OuterSSESyncNode.m_pIConflictsXmlDOMElement.parentNode.removeChild(OuterSSESyncNode.m_pIConflictsXmlDOMElement);
            }

        //  Add the outer SSENode to the merge result collection
        io_MergeSSENodeCollection[io_MergeSSENodeCollection.length] = OuterSSENode;

        //  See if winner SSENode has not been assigned yet or 
        //  if the outer SSENode represents a more recent update
        //  than that of the current winner SSENode
        if ((i_WinnerSSENode == null) || (-1 == CompareSSENodes(i_WinnerSSENode, OuterSSENode)))
            {
            //  Assign the outer SSENode as the winner SSENode
            i_WinnerSSENode = OuterSSENode;
            }
        }

    return i_WinnerSSENode;
    }
    
function CompareSSENodes(i_SSENode1, i_SSENode2)
    {
	//  This function compares the two SSENodes and returns:
	//     1 if i_SSENode1 is newer than i_SSENode2	
	//    -1 if i_SSENode2 is newer than i_SSENode1
	//     0 if SSENodes are equal
	//     null if SSENodes are equal but conflict data is different
	//

	//  Get reference to SSESyncNode for i_SSENode1
	var SSESyncNode1 = i_SSENode1.m_SSESyncNode;
	
	//  Get reference to SSESyncNode for i_SSENode2
	var SSESyncNode2 = i_SSENode2.m_SSESyncNode;

	//  Compare "updates" attributes - if they are equal then do subsequent checks
	if (SSESyncNode1.m_Updates == SSESyncNode2.m_Updates)
		{
		//  Get reference to topmost SSEHistoryNode for SSESyncNode1
		var SSEHistoryNode1 = SSESyncNode1.m_SSEHistoryNodes[0];

		//  Get reference to topmost SSEHistoryNode for SSESyncNode2
		var SSEHistoryNode2 = SSESyncNode2.m_SSEHistoryNodes[0];
						
		//  See if "when" attribute exist for either SSEHistoryNode
		if ((SSEHistoryNode1.m_When != null) || (SSEHistoryNode2.m_When != null))
			{
			//  See if "when" attribute exist for both SSEHistoryNodes
			if ((SSEHistoryNode1.m_When != null) && (SSEHistoryNode2.m_When != null))
				{
				//  Compare date values - since we use RFC3339 values, we can use 
				//  string comparison when comparing datetimes
				if (SSEHistoryNode1.m_When > SSEHistoryNode2.m_When)
					{
					//  SSEHistoryNode1 node has a later "when" attribute, so i_SSENode1
					//  is newer
					return 1;
					}
				else if (SSEHistoryNode2.m_When > SSEHistoryNode1.m_When)
					{
					//  SSEHistoryNode2 node has a later "when" attribute, so i_SSENode2
					//  is newer
					return -1;
					}
				else
					{
					//  Same "when" attribute value for both SSEHistoryNodes - try further 
					//  checking below
					}
				}
			else if (SSEHistoryNode1.m_When != null)
				{
				//  SSEHistoryNode1 has a "when" attribute but SSEHistoryNode2 does not, so
				//  i_SSENode1 is newer
				return 1;
				}
			else
				{
				//  SSEHistoryNode2 has a "when" attribute but SSEHistoryNode1 does not, so
				//  i_SSENode2 is newer
				return -1;
				}
			}
		else
			{
			//  Neither SSEHistoryNode has "when" attribute - try further checking below
			}
		
		//  See if "by" attribute exist for either SSEHistoryNode
		if ((SSEHistoryNode1.m_By != null) || (SSEHistoryNode2.m_By != null))
			{
			//  See if "by" attribute exist for both SSEHistoryNodes
			if ((SSEHistoryNode1.m_By != null) && (SSEHistoryNode2.m_By != null))
				{
				//  Compare "by" values
				if (SSEHistoryNode1.m_By > SSEHistoryNode2.m_By)
					{
					//  SSEHistoryNode1 node has a later "by" attribute, so i_SSENode1
					//  is newer
					return 1;
					}
				else if (SSEHistoryNode1.m_By < SSEHistoryNode2.m_By)
					{
					//  SSEHistoryNode2 node has a later "by" attribute, so i_SSENode2
					//  is newer
					return -1;
					}
				else
					{
					//  Same "by" attribute value for both SSEHistoryNodes - so we must
					//  compare conflict items

					//  If number of conflict item nodes is different, items are equal
					//  but conflict item data is different
					if (SSESyncNode1.m_SSEConflictNodes.length != SSESyncNode2.m_SSEConflictNodes.length)
					    return null;

					//  Check if conflict item nodes exist
					if (SSESyncNode1.m_SSEConflictNodes.length > 0)
					    {
					    //  Iterate conflict nodes for item 1    
					    for (var Index1 = 0; Index1 < SSESyncNode1.m_SSEConflictNodes.length; ++Index)
					        {
					        var MatchingConflictItem = false;
    					    
					        //  Get reference to next conflict node for item 1
					        var ConflictNode1 = SSESyncNode1.m_SSEConflictNodes[Index1];
    					    
					        //  Iterate conflict nodes for item 2
					        for (var Index2 = 0; Index2 < SSESyncNode2.m_SSEConflictNodes.length; ++Index)
					            {
					            //  Get reference to next conflict node for item 2
					            var ConflictNode2 = SSESyncNode2.m_SSEConflictNodes[Index2];
    					        
					            //  Compare conflict nodes
					            if (0 == CompareSSENodes(ConflictNode1, ConflictNode2))
					                {
					                MatchingConflictItem = true;
					                break;
					                }
					            }
					        }
    					    
				        if (!MatchingConflictItem)
				            {
				            //  No matching conflict item - so items are equal but conflict
				            //  item data is different
				            return null;
				            }
					    }
					    
					    //  Items are equal
					    return 0;
					}
				}
			}
		else if (SSEHistoryNode1.m_By != null)
			{
			//  SSEHistoryNode1 has a "by" attribute but SSEHistoryNode2 does not, so
			//  i_SSENode1 is newer
			return 1;
			}
		else if (SSEHistoryNode2.m_By != null)
			{
			//  SSEHistoryNode2 has a "by" attribute but SSEHistoryNode1 does not, so
			//  i_SSENode2 is newer
			return -1;
			}
		else
			{
			//  Neither SSEHistoryNode has "by" attribute - so we can't tell which
			//  SSENode is newer
			return 0;
			}
		}	
	else if (SSESyncNode1.m_Updates> SSESyncNode2.m_Updates)
		{
		//  SSESyncNode1 has a later "updates" attribute, so i_SSENode1 is newer
		return 1;
		}
	else
		{
		//  SSESyncNode2 has a later "updates" attribute, so i_SSENode2 is newer
		return -1;
		}
	}

function CloneSSENode(i_SSENode)
	{
	//  Get reference to original SSENode's XmlDOMElement
	var pIXmlDOMElement = i_SSENode.m_pIXmlDOMElement;
	
	//  Create (deep copy) clone of XmlDOMElement
	var pIClonedXmlDOMElement = pIXmlDOMElement.cloneNode(true);
	
	//  Create new instance of SSENode
	var ClonedSSENode = new SSENodeClass(pIClonedXmlDOMElement);
	
	//  Return new instance of SSENode
	return ClonedSSENode;
	}

function DisplayUsage(i_Text)
	{
	var Text = "Usage:\r\nsseAtomMerge.js [LocalPath] [IncomingPath]\r\n\r\nParameters:\r\n  LocalPath=fully qualified filename of local Atom document (required)\r\n  IncomingPath=fully qualified filename for incoming Atom document (required)\r\n";

	//  If text was provided, prepend it to default usage text
	if ((i_Text != null) && (i_Text != ""))
		Text = i_Text + "\r\n\r\n" + Text;
	
	WScript.Echo(Text);
	}	
